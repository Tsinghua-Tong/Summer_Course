# Tong Summer Course Literature Review Template

This package contains a LaTeX template for the final literature review assignment of
**通用人工智能系统平台 I**.

## Files

- `main.tex`: main template for the literature review.
- `custom.bib`: example BibTeX file. Replace or extend it with the papers you actually cite.
- `acl.sty`: ACL-style formatting file, kept to provide a compact two-column layout.
- `acl_natbib.bst`: bibliography style used by `acl.sty`.
- `acl_lualatex.tex`: optional XeLaTeX/LuaLaTeX example for non-Latin scripts.
- `anthology.bib.txt`: note on using ACL Anthology BibTeX entries.

## How to Use

1. Open the folder in Overleaf or a local LaTeX environment.
2. Edit `main.tex`: replace the title, author information, abstract, section text, tables, and citations.
3. Edit `custom.bib`: keep only the references you actually cite and add new BibTeX entries as needed.
4. Compile `main.tex` with pdfLaTeX and BibTeX.

On Overleaf, choose `main.tex` as the main file. A typical local build sequence is:

```bash
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

If your report is written primarily in Chinese, use XeLaTeX or LuaLaTeX and adapt the font settings
from `acl_lualatex.tex`.

## Course Requirements Reminder

- Review at least 5 closely related papers in one focused subdirection.
- Write 4-6 pages, excluding references and appendices.
- Include a complete reference list.
- Include at least one comparison table or figure.
- Discuss limitations, unresolved questions, and at least two future research directions.
- Submit the compiled PDF, `.tex`, `.bib`, and any separate figure files.
